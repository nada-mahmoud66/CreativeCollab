from DeepImageSearch.DeepImageSearch import Load_Data,Search_Setup
